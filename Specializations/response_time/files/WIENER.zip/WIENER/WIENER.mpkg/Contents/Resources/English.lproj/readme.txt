JAGS WIENER MODULE
For JAGS version 3.x.x on Mac OS X version 10.9 (Mavericks) or later

The JAGS Wiener module is an extension for JAGS, which provides 
wiener process distribution functions, mainly the Wiener first 
passage time density. It allows to include stochastic nodes with 
the first hitting time distribution of a diffusion process.

This is a 64-bit build, linked against libc++ for compatibility 
with the Mavericks build of JAGS version 3.x.x.  This build is 
NOT compatible with the Snow Leopard build of JAGS, which is 
linked against the libc++ library, or versions 2.x or 4x of JAGS.

Note that JAGS must be installed in the default location 
(/usr/local/) - if JAGS has been installed to a customised 
location, you will have to install this module in the same 
location manually.


Installation: 
	
	1.	Download and open the disk image.
	2.	Ensure that the ‘Allow apps downloaded from anywhere’ box is selected in the Security and Privacy (General) pane of System Preferences (this step is only required for OS X 10.8 or later).
	3.	Double click on the disk image to mount (this may not be required).
	4.	Double click on the ‘JAGS-WIENER’ file within the mounted disk image.
	5.	Follow the instructions in the installer.
	6.	Authenticate as the administrative user. The first user you create when setting up Mac OS X has administrator privileges by default.



EXAMPLE
In a model file, you can use:

x ~ dwiener(alpha,tau,beta,delta)
 
With the parameters:
  - alpha being the boundary separation parameter
  - tau being the non-decision time
  - beta being the bias
  - delta being the driftrate

There is also a second distribution:

x ~ dwieners(alpha,tau,beta,delta,1)

with the last parameter as standard deviation of the drift process.

And there are two logical nodes:

  - dwiener(x, alpha,tau,beta,delta)
  - dlogwiener(x, alpha,tau,beta,delta)

to calculate the (log-) density at value x.

PLEASE NOTE
Copyright (C) 2012 Dominik Wabersich <dominik.wabersich@gmail.com>
and Joachim Vandekerckhove <joachim@uci.edu>

When using this module, please cite as: 
    Wabersich, D. and Vandekerckhove, J. (in preparation). Extending JAGS: 
    A tutorial on adding custom distributions to JAGS (with a diffusion
    model example)

LICENSE
This program is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301  USA
